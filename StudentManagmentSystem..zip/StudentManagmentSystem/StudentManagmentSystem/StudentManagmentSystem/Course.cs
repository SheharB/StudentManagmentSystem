﻿using System;
using System.Data.SqlClient;

public class Course
{
    public int CourseID { get; set; }
    public string CourseName { get; set; }
    public int Credits { get; set; }
    public string TeacherName { get; set; }
    private string connectionString = "Data Source=SHEHARBANO;Initial Catalog=SMS;Integrated Security=True";

    public Course(string courseName, int credits, string teacherName)
    {
        CourseName = courseName;
        Credits = credits;
        TeacherName = teacherName;
    }

    public void AddCourse()
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string query = "INSERT INTO Courses (CourseID, CourseName, Credits, TeacherName) VALUES (@CourseID, @CourseName, @Credits, @TeacherName)";

            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@CourseID", CourseID);
                command.Parameters.AddWithValue("@CourseName", CourseName);
                command.Parameters.AddWithValue("@Credits", Credits);
                command.Parameters.AddWithValue("@TeacherName", TeacherName);

                connection.Open();
                int result = command.ExecuteNonQuery();

                if (result < 0)
                    Console.WriteLine("Error adding course!");
                else
                    Console.WriteLine("Course added successfully.");
            }
        }
    }

    public void EnrollInCourse(int studentId, int courseId)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string query = "INSERT INTO StudentEnrollments (StudentID, CourseID) VALUES (@StudentID, @CourseID)";

            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@StudentID", studentId);
                command.Parameters.AddWithValue("@CourseID", courseId);

                connection.Open();
                int result = command.ExecuteNonQuery();

                if (result < 0)
                    Console.WriteLine("Error enrolling in course!");
                else
                    Console.WriteLine("Enrolled in course successfully.");
            }
        }
    }
}
