﻿using System;

public class Program
{
    public static void Main()
    {
        // Assuming the existence of StudentDetails, CourseDetails, Course, and Attendance classes
        StudentDetails studentDetails = new StudentDetails();
        CourseDetails courseDetails = new CourseDetails();
        Course course = new Course("CourseName", 3, "TeacherName");
        Attendance attendance = new Attendance();

        bool exitProgram = false;

        do
        {
            Console.Clear();
            PrintBox("Student Management System");
            Console.WriteLine("1. Enroll Student");
            Console.WriteLine("2. Display All Students");
            Console.WriteLine("3. Add Course");
            Console.WriteLine("4. Display All Courses");
            Console.WriteLine("5. Enroll in a Course");
            Console.WriteLine("6. View Registered Courses");
            Console.WriteLine("7. Take Attendance");
            Console.WriteLine("0. Exit");
            PrintBoxSeparator();
            Console.Write("Enter your choice: ");

            if (int.TryParse(Console.ReadLine(), out int choice))
            {
                switch (choice)
                {
                    case 1:
                        studentDetails.EnrollStudent();
                        break;
                    case 2:
                        studentDetails.DisplayAllStudents();
                        break;
                    case 3:
                        courseDetails.AddCourse();
                        break;
                    case 4:
                        courseDetails.DisplayAllCourses();
                        break;
                    case 5:
                        EnrollInCourse(course);
                        break;
                    case 6:
                        ViewRegisteredCourses(studentDetails);
                        break;
                    case 7:
                        TakeAttendance(attendance);
                        break;
                    case 0:
                        exitProgram = true;
                        PrintBox("Exiting program. Goodbye!");
                        break;
                    default:
                        PrintErrorBox("Invalid choice. Please try again.");
                        break;
                }
            }
            else
            {
                PrintErrorBox("Invalid input. Please enter a number.");
            }

            if (!exitProgram)
            {
                Console.WriteLine("Press any key to return to the main menu...");
                Console.ReadKey();
            }

        } while (!exitProgram);
    }

    private static void EnrollInCourse(Course course)
    {
        Console.Write("Enter Student ID to enroll in a course: ");
        int enrollStudentId = Convert.ToInt32(Console.ReadLine());
        Console.Write("Enter Course ID to enroll in: ");
        int courseId = Convert.ToInt32(Console.ReadLine());
        course.EnrollInCourse(enrollStudentId, courseId);
    }

    private static void ViewRegisteredCourses(StudentDetails studentDetails)
    {
        Console.Write("Enter Student ID to view registered courses: ");
        int viewStudentId = Convert.ToInt32(Console.ReadLine());
        studentDetails.ViewRegisteredCourses(viewStudentId);
    }

    private static void TakeAttendance(Attendance attendance)
    {
        Console.Write("Enter Course ID for taking attendance: ");
        int courseIdForAttendance = Convert.ToInt32(Console.ReadLine());
        attendance.TakeAttendance(courseIdForAttendance);
    }

    // Helper Methods for Box Output
    private static void PrintBox(string message)
    {
        int width = message.Length + 4;
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine(new string('=', width));
        Console.WriteLine($"| {message} |");
        Console.WriteLine(new string('=', width));
        Console.ResetColor();
    }

    private static void PrintBoxSeparator()
    {
        Console.WriteLine(new string('-', 40));
    }

    private static void PrintErrorBox(string message)
    {
        int width = message.Length + 4;
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine(new string('=', width));
        Console.WriteLine($"| {message} |");
        Console.WriteLine(new string('=', width));
        Console.ResetColor();
    }
}
