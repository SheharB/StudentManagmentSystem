﻿using System;
using System.Data.SqlClient;

public class CourseDetails
{
    private string connectionString = "Data Source=SHEHARBANO;Initial Catalog=SMS;Integrated Security=True";

    public int AddTeacher()
    {
        Console.Write("Enter Teacher's First Name: ");
        string firstName = Console.ReadLine();
        Console.Write("Enter Teacher's Last Name: ");
        string lastName = Console.ReadLine();

        return InsertTeacherIntoDatabase(firstName, lastName);
    }

    private int InsertTeacherIntoDatabase(string firstName, string lastName)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string query = "INSERT INTO Teachers (FirstName, LastName) VALUES (@FirstName, @LastName); SELECT SCOPE_IDENTITY();";

            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@FirstName", firstName);
                command.Parameters.AddWithValue("@LastName", lastName);

                connection.Open();
                int teacherId = Convert.ToInt32(command.ExecuteScalar());

                if (teacherId > 0)
                    PrintSuccessBox("Teacher added successfully.");
                else
                    PrintErrorBox("Error adding the teacher!");

                return teacherId;
            }
        }
    }

    public void AddCourse()
    {
        Console.Write("Enter Course Name: ");
        string courseName = Console.ReadLine();
        Console.Write("Enter Credits: ");
        int credits = Convert.ToInt32(Console.ReadLine());

        int teacherId = AddTeacher();

        InsertCourseIntoDatabase(courseName, credits, teacherId);
    }

    private void InsertCourseIntoDatabase(string courseName, int credits, int teacherId)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string query = "INSERT INTO Courses (CourseName, Credits, TeacherID) VALUES (@CourseName, @Credits, @TeacherID)";

            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@CourseName", courseName);
                command.Parameters.AddWithValue("@Credits", credits);
                command.Parameters.AddWithValue("@TeacherID", teacherId);

                connection.Open();
                int result = command.ExecuteNonQuery();

                if (result < 0)
                    PrintErrorBox("Error inserting data into Database!");
                else
                    PrintSuccessBox("Course added successfully.");
            }
        }
    }

    public void DisplayAllCourses()
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string query = "SELECT c.CourseID, c.CourseName, c.Credits, t.FirstName, t.LastName FROM Courses c JOIN Teachers t ON c.TeacherID = t.TeacherID";

            using (SqlCommand command = new SqlCommand(query, connection))
            {
                connection.Open();
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    // Print the "Available Courses" header with a different color
                    PrintBox("Available Courses:", ConsoleColor.Yellow);

                    while (reader.Read())
                    {
                        string courseId = reader["CourseID"].ToString();
                        string courseName = reader["CourseName"].ToString();
                        string credits = reader["Credits"].ToString();
                        string teacherName = $"{reader["FirstName"]} {reader["LastName"]}";

                        // Combine all information into a single line
                        string courseInfo = $"ID: {courseId}, Name: {courseName}, Credits: {credits}, Teacher: {teacherName}";

                        // Print the combined information in a single box
                        PrintBox(courseInfo);
                    }
                }
            }
        }
    }



    public void TakeAttendance(int courseId)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string query = @"SELECT s.StudentID, s.FirstName, s.LastName 
                             FROM Students s
                             JOIN StudentEnrollments se ON s.StudentID = se.StudentID
                             WHERE se.CourseID = @CourseID";

            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@CourseID", courseId);
                connection.Open();
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        PrintBox($"ID: {reader["StudentID"]}, Name: {reader["FirstName"]} {reader["LastName"]}");
                        Console.Write("Mark Present (Y/N): ");
                        string attendance = Console.ReadLine();

                        RecordAttendance(courseId, Convert.ToInt32(reader["StudentID"]), attendance);
                    }
                }
            }
        }
    }

    private void RecordAttendance(int courseId, int studentId, string attendance)
    {
        string status = attendance.Equals("Y", StringComparison.OrdinalIgnoreCase) ? "Present" : "Absent";

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string query = "INSERT INTO Attendance (CourseID, StudentID, DateAttended, Status) VALUES (@CourseID, @StudentID, @DateAttended, @Status)";

            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@CourseID", courseId);
                command.Parameters.AddWithValue("@StudentID", studentId);
                command.Parameters.AddWithValue("@DateAttended", DateTime.Today);
                command.Parameters.AddWithValue("@Status", status);

                connection.Open();
                int result = command.ExecuteNonQuery();

                if (result < 0)
                    PrintErrorBox("Error recording attendance!");
                else
                    PrintSuccessBox($"Attendance recorded: Student ID {studentId} - {status}");
            }
        }
    }

    private static void PrintBox(string message, ConsoleColor headerColor = ConsoleColor.Cyan)
    {
        int width = message.Length + 4;

        // Set the color for the header
        Console.ForegroundColor = headerColor;
        Console.WriteLine(new string('=', width));
        Console.WriteLine($"| {message} |");
        Console.WriteLine(new string('=', width));
        Console.ResetColor();
    }


    private static void PrintSuccessBox(string message)
    {
        int width = message.Length + 4;
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine(new string('=', width));
        Console.WriteLine($"| {message} |");
        Console.WriteLine(new string('=', width));
        Console.ResetColor();
    }

    private static void PrintErrorBox(string message)
    {
        int width = message.Length + 4;
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine(new string('=', width));
        Console.WriteLine($"| {message} |");
        Console.WriteLine(new string('=', width));
        Console.ResetColor();
    }
}
