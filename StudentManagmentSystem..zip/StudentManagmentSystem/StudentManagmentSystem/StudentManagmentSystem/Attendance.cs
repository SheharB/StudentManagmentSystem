﻿using System;
using System.Data.SqlClient;

public class Attendance
{
    private string connectionString = "Data Source=SHEHARBANO;Initial Catalog=SMS;Integrated Security=True";

    public void TakeAttendance(int courseId)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            // Query to select all students enrolled in the specified course
            string query = @"SELECT s.StudentID, s.FirstName, s.LastName 
                         FROM Students s
                         JOIN StudentEnrollments se ON s.StudentID = se.StudentID
                         WHERE se.CourseID = @CourseID";

            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@CourseID", courseId);
                connection.Open();
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    Console.WriteLine("=================================");
                    Console.WriteLine("|    Take Attendance for Course   |");
                    Console.WriteLine("=================================");

                    while (reader.Read())
                    {
                        int studentId = Convert.ToInt32(reader["StudentID"]);
                        string studentName = reader["FirstName"] + " " + reader["LastName"];

                        Console.WriteLine("=================================");
                        Console.WriteLine($"| ID: {studentId}, Name: {studentName} |");
                        Console.WriteLine("=================================");
                        Console.Write("Mark Present (Y/N): ");
                        string attendance = Console.ReadLine();

                        RecordAttendance(courseId, studentId, attendance);
                    }
                }
            }
        }
    }


    private void RecordAttendance(int courseId, int studentId, string attendance)
    {
        string status = attendance.Equals("Y", StringComparison.OrdinalIgnoreCase) ? "Present" : "Absent";

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string query = "INSERT INTO Attendance (CourseID, StudentID, DateAttended, Status) VALUES (@CourseID, @StudentID, @DateAttended, @Status)";

            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@CourseID", courseId);
                command.Parameters.AddWithValue("@StudentID", studentId);
                command.Parameters.AddWithValue("@DateAttended", DateTime.Today);
                command.Parameters.AddWithValue("@Status", status);

                connection.Open();
                int result = command.ExecuteNonQuery();

                if (result < 0)
                    Console.WriteLine("Error recording attendance for Student ID " + studentId);
                else
                {
                    if (status == "Present")
                    {
                        Console.ForegroundColor = ConsoleColor.Green; // Set text color to green for present students
                        Console.WriteLine($"Attendance recorded: Student ID {studentId} - {status}");
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red; // Set text color to red for absent students
                        Console.WriteLine($"Attendance recorded: Student ID {studentId} - {status}");
                    }

                    Console.ResetColor(); // Reset text color to default
                }
            }
        }
    }


}
