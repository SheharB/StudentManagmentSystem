﻿using System;
using System.Data.SqlClient;

public class StudentDetails
{
    private string connectionString = "Data Source=SHEHARBANO;Initial Catalog=SMS;Integrated Security=True";

    public void EnrollStudent()
    {
        Console.Write("Enter First Name: ");
        string firstName = Console.ReadLine();
        Console.Write("Enter Last Name: ");
        string lastName = Console.ReadLine();

        InsertStudentIntoDatabase(firstName, lastName);
    }

    private void InsertStudentIntoDatabase(string firstName, string lastName)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string query = "INSERT INTO Students (FirstName, LastName) VALUES (@FirstName, @LastName)";

            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@FirstName", firstName);
                command.Parameters.AddWithValue("@LastName", lastName);

                connection.Open();
                int result = command.ExecuteNonQuery();

                if (result < 0)
                    PrintErrorBox("Error inserting data into Database!");
                else
                    PrintSuccessBox("Student enrolled successfully.");
            }
        }
    }

    public void DisplayAllStudents()
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string query = "SELECT StudentID, FirstName, LastName FROM Students";

            using (SqlCommand command = new SqlCommand(query, connection))
            {
                connection.Open();
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    PrintBox("Enrolled Students:");
                    while (reader.Read())
                    {
                        PrintBox($"ID: {reader["StudentID"]}, Name: {reader["FirstName"]} {reader["LastName"]}");
                    }
                }
            }
        }
    }

    public void ViewRegisteredCourses(int studentId)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string query = "SELECT c.CourseID, c.CourseName, c.Credits " +
                           "FROM Courses c JOIN StudentEnrollments se ON c.CourseID = se.CourseID " +
                           "WHERE se.StudentID = @StudentID";

            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@StudentID", studentId);
                connection.Open();
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    PrintBox($"Courses for Student ID {studentId}:");
                    while (reader.Read())
                    {
                        PrintBox($"ID: {reader["CourseID"]}, Name: {reader["CourseName"]}, Credits: {reader["Credits"]}");
                    }
                }
            }
        }
    }

    // Helper methods to print in boxes
    private static void PrintBox(string message)
    {
        int width = message.Length + 4;
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine(new string('=', width));
        Console.WriteLine($"| {message} |");
        Console.WriteLine(new string('=', width));
        Console.ResetColor();
    }

    private static void PrintSuccessBox(string message)
    {
        int width = message.Length + 4;
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine(new string('=', width));
        Console.WriteLine($"| {message} |");
        Console.WriteLine(new string('=', width));
        Console.ResetColor();
    }

    private static void PrintErrorBox(string message)
    {
        int width = message.Length + 4;
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine(new string('=', width));
        Console.WriteLine($"| {message} |");
        Console.WriteLine(new string('=', width));
        Console.ResetColor();
    }
}
