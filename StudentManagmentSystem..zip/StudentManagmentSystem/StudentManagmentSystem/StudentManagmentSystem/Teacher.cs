﻿public class Teacher
{
    public int TeacherID { get; set; }
    public string TeacherName { get; set; }

    // Constructor
    public Teacher(int teacherId, string teacherName)
    {
        TeacherID = teacherId;
        TeacherName = teacherName;
    }

    // Additional methods as needed
}
